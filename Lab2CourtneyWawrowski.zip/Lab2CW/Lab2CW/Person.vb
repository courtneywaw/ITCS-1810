﻿Public Class Person

    Public firstname As String
    Public lastname As String

    Public Function fullname() As String
        Return firstname & " " & lastname

    End Function

End Class
