﻿Public Class Pet

    Public petname As String
    Public age As Integer
    Public species As String
    Public owner As Person


End Class
